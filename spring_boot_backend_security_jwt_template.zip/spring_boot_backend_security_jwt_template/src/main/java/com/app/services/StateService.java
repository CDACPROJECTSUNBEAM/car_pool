package com.app.services;

import java.util.List;

import com.app.dtos.StateDTO;

public interface StateService {
	public List<StateDTO> getAllStates();
}
