package com.app.services;

import com.app.dtos.VehicleDTO;

import java.util.List;

public interface VehicleService {
    public List<VehicleDTO> getAllVehicles();
}
