package com.app.services;

import java.util.List;

import com.app.dtos.CityDTO;

public interface CityService {
	public List<CityDTO> getAllCities();
}
