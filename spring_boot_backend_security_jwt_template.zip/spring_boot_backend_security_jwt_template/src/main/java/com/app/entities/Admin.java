//package com.app.entities;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.ToString;
//
//@Entity
//@Getter
//@Setter
//@ToString
//@NoArgsConstructor
//public class Admin extends BaseEntity {
//	
//	@Column(length = 35, nullable = false)
//	private String email;
//
//	@Column(length = 35, nullable = false)
//	private String password;
//	
//}
