package com.app.entities;

public enum StatusType {
    PENDING, ACCEPTED, REJECTED
}
