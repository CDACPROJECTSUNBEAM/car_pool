package com.app.entities;

public enum RoleType {
	ROLE_USER, ROLE_DRIVER, ROLE_ADMIN
}
